The resources that used are mainly from 
the Udacity course maaterial 
Bikeshare data python file
Google and Stackoverflow 
https://stackoverflow.com/questions/30222533/create-a-day-of-week-column-in-a-pandas-dataframe-using-python